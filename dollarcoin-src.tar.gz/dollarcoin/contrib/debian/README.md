
Debian
====================
This directory contains files used to package dollarcoind/dollarcoin-qt
for Debian-based Linux systems. If you compile dollarcoind/dollarcoin-qt yourself, there are some useful files here.

## dollarcoin: URI support ##


dollarcoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install dollarcoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your dollarcoin-qt binary to `/usr/bin`
and the `../../share/pixmaps/dollarcoin128.png` to `/usr/share/pixmaps`

dollarcoin-qt.protocol (KDE)

