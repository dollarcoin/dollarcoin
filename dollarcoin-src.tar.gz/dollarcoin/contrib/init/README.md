Sample configuration files for:
```
SystemD: dollarcoind.service
Upstart: dollarcoind.conf
OpenRC:  dollarcoind.openrc
         dollarcoind.openrcconf
CentOS:  dollarcoind.init
OS X:    org.dollarcoin.dollarcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
